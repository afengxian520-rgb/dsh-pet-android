# 手机操作卡：上传修复工作流并启动 v1.8.5 构建

你只需要把下面这个 `.yml` 文件上传到 GitHub，不需要手动编辑代码，也不用删除原来的 `main.yml`。

## 手机上照着按

1. 先在 ChatGPT 里下载本包中的 `dsh-pet-v1.8.5-offline-companion-anchor-fix.yml`。如果你下载的是 ZIP，打开手机“文件管理/Files”→“下载”，点 ZIP →“解压”。
2. 打开 Chrome，进入这个精确地址：
   https://github.com/afengxian520-rgb/dsh-pet-android/tree/main/.github/workflows
3. 如果 GitHub 让你登录，登录你自己的 GitHub 账号。不要把密码或令牌发给 ChatGPT。
4. 在页面右上/文件列表附近点 **Add file**（添加文件）→ **Upload files**（上传文件）。如果手机页面太窄，Chrome 菜单里切换“桌面版网站”。
5. 上传解压出来的唯一文件：`dsh-pet-v1.8.5-offline-companion-anchor-fix.yml`。一定要在 `.github/workflows/` 这个目录里上传；不要上传整个 ZIP，不要覆盖或删除 `main.yml`，也不要改扩展名。
6. 滑到页面底部，点 **Commit changes**（提交更改），使用默认提交说明即可。该提交到 `main` 后会自动触发工作流。
7. 打开：
   https://github.com/afengxian520-rgb/dsh-pet-android/actions
   找到名称完全匹配 **Build Android APK - v1.8.5 Offline Companion (Anchor Fix)** 的运行。其他叫 **Build Android APK** 的运行是旧工作流，不要混淆。
8. 打开本次运行，等它显示 **completed**。如果是绿色 **success**，在页面底部 Artifacts 下载 `bigfish-v1.8.5-offline-companion-apk`，解压后找 `dsh-pet-full-v1.8.5.apk`。只有这个新工作流的这次成功运行才是目标新包。
9. 如果失败，不要反复重跑，也不要装旧包充数。把这次运行的网址发回 ChatGPT，或截下失败步骤的名称和日志；ChatGPT 可继续根据真实日志检查。

## 你现在不用做的事
- 不用再来回打开权限设置；之前的 ChatGPT GitHub 写入接口返回 403，说明当前连接不能提交代码。通过你自己已登录的 GitHub 网页上传这一份文件，是眼下最短的可行路线。
- 不要上传 `dsh-pet-v1.8.5-最终静态核验包.zip` 来替代 yml；ZIP 是资料包，不是工作流文件。
- 不要安装旧 `main.yml` 成功运行产出的 `app-debug.apk` 作为 v1.8.5：它是基础旧构建，里面没有 `a001.webp`–`a106.webp` 动画资源。

## 发生什么就怎么办
- 找不到 Add file：确认浏览器地址以 `/.github/workflows` 结尾，必要时切换 Chrome“桌面版网站”。
- 上传后没看到新工作流：确认文件在 `.github/workflows/`，名字是 `.yml` 结尾，并提交到了 `main`。
- 新工作流红色失败：把 run URL 发给 ChatGPT；不需要你判断是哪一种编译错误。
- 成功但找不到 APK：确认你打开的是 Anchor Fix 那次运行，再找 Artifacts；只有成功运行且 artifact 存在，才算产物生成。

本文件名：`dsh-pet-v1.8.5-offline-companion-anchor-fix.yml`
构建工作流名称：`Build Android APK - v1.8.5 Offline Companion (Anchor Fix)`
目标 Artifact：`bigfish-v1.8.5-offline-companion-apk`
目标 APK：`dsh-pet-full-v1.8.5.apk`
